using System.Text;
// Author: Frank Robson
// Organisation: South Metropolitan TAFE
// Title: My Notepad
// Description:
//      Notepad application
// Version 1: 8/8/2022
//      Simple Notepad application to demonstrate File reading and writing
//      Open file dialog and Save file dialog
namespace MyNotepad
{
    public partial class frmPage : Form
    {
        public frmPage()
        {
            InitializeComponent();
         }

        // initial path set to nothing to ensure no reading or writing until a file is selected
        string path = "";
        // track changed status of textbox
        bool textChanged = false;
        // file loading flag
        bool fileLoading = false;

        /// <summary>
        /// The open file dialog and read to the text box
        /// </summary>
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog
            {
                // directory to be displayed when the dialog first appears
                InitialDirectory = @"C:\",
                // title of the dialog box
                Title = "Browse Text Files",

                // a warning will be given if a file does not exist
                CheckFileExists = true,
                // a warning will be given if a path does not exist
                CheckPathExists = true,

                // sets the default extension to txt
                DefaultExt = "txt",
                // filter only shows txt files
                Filter = "txt files (*.txt)|*.txt",
                FilterIndex = 2,
                // current directory is restored on closing
                RestoreDirectory = true,

                // ReadOnlyChecked property represents whether the read-only checkbox is selected
                // ShowReadOnly property represents whether the read-only checkbox is available or not
                ReadOnlyChecked = true,
                ShowReadOnly = true
            };

            // Update the title of the form with the opened filename and path
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                this.Text = "Notepad: " + openFileDialog1.FileName;


                // set the file path to the selected file
                path = openFileDialog1.FileName;

                // set the file loading state to true
                fileLoading = true;

                // Open the file and read it to the text box on the form  
                using (FileStream fs = File.OpenRead(path))
                {
                    // empty the current content of the text box
                    rtbFileContent.Text = "";

                    // read each byte from the file and add it to the textbox
                    byte[] b = new byte[1024];
                    UTF8Encoding temp = new UTF8Encoding(true);
                    while (fs.Read(b, 0, b.Length) > 0)
                    {
                        rtbFileContent.Text += temp.GetString(b);
                    }
                }

                // set the file loading state to false
                fileLoading = false;
            }
        }

        /// <summary>
        /// The simple save file method
        /// </summary>
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!path.Equals(""))
            {
                // Delete the file if it exists.  
                if (File.Exists(path))
                {
                    File.Delete(path);
                }

                //Create the file.  
                using (FileStream fs = File.Create(path))
                {
                    byte[] info = new UTF8Encoding(true).GetBytes(rtbFileContent.Text);
                    fs.Write(info, 0, info.Length);
                }

                // set the textbox changed status back to false
                textChanged = false;
            }
        }

        /// <summary>
        /// The save as option with save file dialog example
        /// </summary>
        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFile();
        }
        private void saveFile()
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog
            {
                // title of the dialog box
                Title = "Browse Text Files",

                // a warning will be given if a path does not exist
                CheckPathExists = true,

                // sets the default extension to txt
                DefaultExt = "txt",

                // filter only shows txt files
                Filter = "txt files (*.txt)|*.txt",
                FilterIndex = 2,

                // current directory is restored on closing
                RestoreDirectory = true,

            };

            // Update the title of the form with the saved filename and path
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                this.Text = "Notepad: " + saveFileDialog1.FileName;
            }

            // set the file path to the selected file
            path = saveFileDialog1.FileName;

            if (!path.Equals(""))
            {
                // Delete the old file if it exists.  
                if (File.Exists(path))
                {
                    File.Delete(path);
                }

                //Create the file.  
                using (FileStream fs = File.Create(path))
                {
                    // turn the content of the text box to bytes and dump it in the file
                    byte[] info = new UTF8Encoding(true).GetBytes(rtbFileContent.Text);
                    fs.Write(info, 0, info.Length);
                }
            }

            // set the textbox changed status back to false
            textChanged = false;
        }

        /// <summary>
        /// check for unsaved changes on exiting the program and give the save as option
        /// </summary>
 
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (textChanged)
            {
                saveFile();
            }

            Application.Exit();

        }

        /// <summary>
        /// Respond to any change in the text box
        /// </summary>

        private void rtbFileContent_TextChanged(object sender, EventArgs e)
        {
            if (!fileLoading)
            {
                // set the textbox changed status to true to indicate that there are unsaved changes
                textChanged = true;
            }
        }

        /// <summary>
        /// Responds to the form closed using the window close icon
        /// Demonstrates how to call an event
        /// </summary>

        private void frmPage_FormClosing(object sender, FormClosingEventArgs e)
        {
            exitToolStripMenuItem_Click(sender, e);
        }
    }
}